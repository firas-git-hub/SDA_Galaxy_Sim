class Constants:
    MassOfSun = 1.988435e30
    ParsecInMeter = 3.08567758129e16
    Gamma = 6.67428e-11
